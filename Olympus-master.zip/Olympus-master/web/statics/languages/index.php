<?php

/**
 * Silence is golden
 */
